﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab1.ViewModels
{
	public class LabModel
	{
		public int firstRndNum { get; set; }
		public int secondRndNum { get; set; }
		public int sumResult { get; set; }
		public int subResult { get; set; }
		public int mulResult { get; set; }
		public int divResult { get; set; }
	}
}
